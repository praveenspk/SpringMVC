package com.huawei.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.huawei.entity.Employee;
import com.huawei.service.EmpService;

@Controller
@RequestMapping("/employee")
public class EmpController {

	@Autowired
	private EmpService service;
	
	
	@GetMapping("/showForm")
	public String showFormForAdd(Model theModel) {
		Employee employee = new Employee();
		theModel.addAttribute("Employee", employee);
		return "Employee-form";
	}

	@PostMapping("/saveEmployee")
	public String saveEmployee(@ModelAttribute("Employee") Employee employee) {
		service.saveEmployee(employee);
		return "redirect:/Employee/list";
	}

	@GetMapping("/list")
	public String listemps(Model theModel) {
		List<Employee> employee = service.getEmps();
		theModel.addAttribute("employees", employee);
		return "list-employees";
	}

	@GetMapping("/updateForm")
	public String showFormForUpdate(@RequestParam("empId") int empId, Model theModel) {
		Employee employee = service.getEmployee(empId);
		theModel.addAttribute("Employee", employee);
		return "Employee-form";
	}

	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam("empId") int empId) {
		service.deleteEmployee(empId);
		return "redirect:/Employee/list";
	}
	

}
