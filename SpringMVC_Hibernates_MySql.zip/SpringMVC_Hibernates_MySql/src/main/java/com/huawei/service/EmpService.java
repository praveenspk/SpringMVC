package com.huawei.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.huawei.entity.Employee;

@Service
public interface EmpService {
	
	public List<Employee> getEmps();
	
	public void saveEmployee(Employee employee);

	public Employee getEmployee(int empId);

	public void deleteEmployee(int empId);


}
