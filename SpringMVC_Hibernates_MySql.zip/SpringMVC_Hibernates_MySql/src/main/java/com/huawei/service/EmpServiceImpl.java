package com.huawei.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huawei.dao.EmpDAO;
import com.huawei.entity.Employee;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired
	private EmpDAO dao;

	@Transactional
	public List<Employee> getEmps() {
		// TODO Auto-generated method stub
		return dao.getEmps();
	}

	@Transactional
	public void saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		dao.saveEmp(employee);
	}

	@Transactional
	public Employee getEmployee(int empId) {
		// TODO Auto-generated method stub
		return dao.getEmpById(empId);
	}

	@Transactional
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		dao.deleteEmp(empId);

	}

}
