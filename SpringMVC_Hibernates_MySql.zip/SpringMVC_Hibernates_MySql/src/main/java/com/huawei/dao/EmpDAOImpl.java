package com.huawei.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.huawei.entity.Employee;

@Repository
public class EmpDAOImpl implements EmpDAO {

	@Autowired
	private SessionFactory factory;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.huawei.dao.EmpDAO#getEmps()
	 */
	
	public List<Employee> getEmps() {
		// TODO Auto-generated method stub
		Session session = factory.getCurrentSession();
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);
		Root<Employee> root = cq.from(Employee.class);
		cq.select(root);
		Query query = session.createQuery(cq);
		return query.getResultList();

	}

	public void saveEmp(Employee employee) {
		// TODO Auto-generated method stub
		Session session = factory.getCurrentSession();
		session.saveOrUpdate(employee);

	}

	public Employee getEmpById(int empId) {
		// TODO Auto-generated method stub
		Session session = factory.getCurrentSession();
		Employee employee = session.get(Employee.class, empId);
		return employee;
	}

	public void deleteEmp(int empId) {
		// TODO Auto-generated method stub
		Session session=factory.getCurrentSession();
		Employee emp=session.byId(Employee.class).load(empId);
		session.delete(emp);
	}

}
