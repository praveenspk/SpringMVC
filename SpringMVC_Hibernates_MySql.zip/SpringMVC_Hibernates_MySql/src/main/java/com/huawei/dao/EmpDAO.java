package com.huawei.dao;

import java.util.List;

import com.huawei.entity.Employee;

public interface EmpDAO {

	public List<Employee> getEmps();

	public void saveEmp(Employee employee);

	public Employee getEmpById(int empId);

	public void deleteEmp(int empId);

}
